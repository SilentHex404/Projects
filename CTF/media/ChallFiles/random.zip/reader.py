
# ............................................................................................................................


from PIL import Image

message = "*_*"

shifted_message = ''.join(chr(ord(c) + 1) for c in message)

binary_message = ''.join(format(ord(c), '08b') for c in shifted_message)

key_bytes = [0x66, 0x6c, 0x61, 0x67]

o_bib = ""
for i in range(0, len(binary_message), 8):
    byte = int(binary_message [i:i+8], 2)
    key_byte = bytes(key_bytes)[(i // 8) % len(bytes(key_bytes))]
    xor_byte = byte ^ key_byte
    o_bib += format(xor_byte, '08b')
    
img = Image.open('images.jpg').convert('RGB')
pixels = img.load()
width, height = img.size

bit_index = 0
done = False

for y in range(height):
    for x in range(width):
        if bit_index >= len(o_bib):
            done = True
            break
        
        r, g, b = pixels[x, y]
        new_rgb = []

        for color in (r, g, b):
            if bit_index < len(o_bib):
                color_bin = format(color, '08b')
                
                new_bin = color_bin[:-1] + o_bib[bit_index]
                new_rgb.append(int(new_bin, 2))
                bit_index += 1
            else:
                new_rgb.append(color)

        pixels[x, y] = tuple(new_rgb)
    
    if done:
        break

img.save('new_secret.png')
print("Secret saved successfully✔️")